package hs.lessonReserve;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LessonReserveApplication {

	public static void main(String[] args) {
		SpringApplication.run(LessonReserveApplication.class, args);
	}

}
